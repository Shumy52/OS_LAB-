echo Welcome to the shitshow



for i in {1..$#..$p1}
do
    echo -n \"$p\"" "
done

echo the shitshow doesn't work