//
// Created by kali on 3/17/24.
//

#ifndef CODE_PROBLEM1_H
#define CODE_PROBLEM1_H


class Problem1 {

};


#endif //CODE_PROBLEM1_H
